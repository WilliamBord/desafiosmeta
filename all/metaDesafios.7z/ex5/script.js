function valida(){
	var resultado = parseInt(document.getElementById('resultado').value);
	var resultadodois = parseInt(document.getElementById('resultadodois').value);
	var tt = (resultado + resultadodois)/2;

		alert("O RESULTADO É: "+ tt);
	}

	

