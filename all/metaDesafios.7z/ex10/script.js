function valida(){
var res = Math.sqrt(9);
	alert("RAÍZ QUADRADA DE 9 É: " + res);
}

