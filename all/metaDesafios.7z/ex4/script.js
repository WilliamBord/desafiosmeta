function valida(){ 
	for(var count=1; count<=10 ; count++)
	alert("2 x "+count+" = " + (2*count));

}