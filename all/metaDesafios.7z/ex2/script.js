function valida(){
	var r = parseInt(document.getElementById('r').value); var f = parseInt(document.getElementById('f').value);
	var t = r + f; var b = Math.pow(t, 2);
		alert("O RESULTADO É: "+ b);
	}

	

