function valida(){
	var r = document.getElementById('r'); var t = Math.pow(r.value, 2);
		alert("O RESULTADO É: "+ t);
	}

