function valida(){
	var t = (20000 - 7000)  /20000; var r = t * 100;
	alert("FALTA " + r +"%");
}

